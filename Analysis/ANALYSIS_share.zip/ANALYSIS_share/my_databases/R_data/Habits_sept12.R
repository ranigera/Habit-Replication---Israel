### R Code for HABIT analysis
### Created on August 2017

# ------------------------ PRELIMINARY STUFF ----------------------------------------

# Set working directory
analysis_path <- '/Users/evapool/Box Sync/HABITS_REPLICATION/ANALYSIS/my_databases/txt_data'

setwd(analysis_path)

# open dataset
PRESS   <- read.delim('/Users/evapool/Box Sync/HABITS_REPLICATION/ANALYSIS/my_databases/txt_data/presses_SEP_12.txt', header = T, sep ='') # read in dataset
FRACTAL <- read.delim('/Users/evapool/Box Sync/HABITS_REPLICATION/ANALYSIS/my_databases/txt_data/fractal_ratings_SEP_12.txt', header = T, sep ='') # read in dataset
FOOD    <- read.delim('/Users/evapool/Box Sync/HABITS_REPLICATION/ANALYSIS/my_databases/txt_data/food_liking_SEP_12.txt', header = T, sep ='') # read in dataset

# define factors
PRESS$ID     <- factor(PRESS$ID)
PRESS$value  <- factor(PRESS$value)
PRESS$group  <- factor(PRESS$group)

FRACTAL$ID     <- factor(FRACTAL$ID)
FRACTAL$value  <- factor(FRACTAL$value)
FRACTAL$group  <- factor(FRACTAL$group)

FOOD$ID        <- factor(FOOD$ID)
FOOD$value     <- factor(FOOD$value)
FOOD$group     <- factor(FOOD$group)

# load library
library(lme4)
library(ggplot2)
library(multcomp)
library(pbkrtest)
library(dplyr)

#------------------------ ANALYSIS ON PRESSES ----------------------------------------

# remove the baseline condition from the data
PRESS <- subset(PRESS, value == 'valued' | value == 'devalued')

# create databases by group for planned comparisons
PRESS_1DAY  <- subset(PRESS, group == '1')
PRESS_3DAY  <- subset(PRESS, group == '3')

PRESS_VALUED  <- subset(PRESS, value == 'valued')
PRESS_DEVALUED  <- subset(PRESS, value == 'devalued')

PRESS_1DAY_VALUED  <- subset(PRESS, group == '1' & value == 'valued')
PRESS_1DAY_DEVALUED  <- subset(PRESS, group == '1' & value == 'devalued')
PRESS_3DAY_VALUED  <- subset(PRESS, group == '3' & value == 'valued')
PRESS_3DAY_DEVALUED  <- subset(PRESS, group == '3' & value == 'devalued')

# overall ANOVA
summary(aov(presses_change ~ group*value + Error(ID / (value )), data= PRESS)) 
summary(aov(presses_post ~ group*value + Error(ID / (value )), data= PRESS)) 

# planned comparaisons
# day1 group (we expect this significant)
summary(aov(presses_change ~ value + Error(ID / (value )), data= PRESS_1DAY)) 
summary(aov(presses_post ~ value + Error(ID / (value )), data= PRESS_1DAY)) 

# day3 group (we expect this NOT to be significant)
summary(aov(presses_change ~ value + Error(ID / (value )), data= PRESS_3DAY)) 
summary(aov(presses_post ~ value + Error(ID / (value )), data= PRESS_3DAY)) 
