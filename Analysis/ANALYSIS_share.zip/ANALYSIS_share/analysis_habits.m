%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ANALYSIS SCRIPT FOR HABITS-replication of behavioral findings of Tricomi et al.,
% 2009

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% last modified on SEPTEMBER 2017 by Eva

close all
clear all

%% INPUT VARIABLE

graph_on          = 1;
extract_subj_data = 1;
save_results      = 0;
build_Rdatabase   = 0;
all_subjects      = 1;

analysis_name     = 'SEP_12';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1-days Group

% subj              = {'01'; '02'; '03'; '04'; '05'; '06'; '07'; '08'; '09'; '10';'11'; '12'; '13';'14'; '15';'16';'17';'18';'19'; '20'; '21'; '22'; '23';'24';'25';'26';'27'; '28'; '29'; '30'}; % participant ID
% group             = [  1     1     1    1     1     1     1     1     1     1    1    1     1     1    1     1    1    1     1    1     1     1     1    1    1    1    1     1     1      1] ; % group
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3-days Group

% subj              = { '100'; '101';'102';'103';'104'; '106';'107';'108';'110';'111';'113';'114';'115';'116'; '118'; '119'; '120'; '121';  '123'; '124'; '125'; '126'; '127'; '128'; '129'; '130'; '131'; '132'; '133';'134'; '135' }; % participant ID
% group             = [    2      2     2     2     2      2     2     2     2     2     2     2     2     2      2     2      2      2        2      2      2      2      2      2      2      2      2      2      2     2      2  ]; % group


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ALL PARTICIPANTS 

subj              = {'01'; '02'; '03'; '04'; '05'; '06'; '07'; '08'; '09'; '10';'11'; '12'; '13';'14'; '15';'16';'17';'18';'19'; '20'; '21'; '22'; '23';'24';'25';'26';'27'; '28'; '29'; '30'; '31';'100'; '101';'102';'103';'104'; '106';'107';'108';'110';'111';'113';'114';'115';'116'; '118'; '119'; '120'; '121';  '123'; '124'; '125'; '126'; '127'; '128'; '129'; '130'; '131'; '132'; '133';'134'; '135' }; % participant ID
group             = [  1     1     1     1     1     1     1     1     1     1    1    1     1     1    1     1    1    1     1    1     1     1     1    1    1    1    1     1     1      1    1     2      2     2     2     2      2     2     2     2     2     2     2     2     2      2     2      2      2        2      2      2      2      2      2      2      2      2      2      2     2      2 ] ; % group


homedir           = '/Users/evapool/Box Sync/HABITS_REPLICATION/'; % change this so that it correspond to your analysis folder
%homedir           = '/Users/Mladena/Box Sync/HABITS';
questionnaire_dir = fullfile(homedir,'DATA/questionnaires');
behavior_dir      = fullfile(homedir,'DATA/behavior');
analysis_dir      = fullfile(homedir,'ANALYSIS/');

%outputs
results_dir       = fullfile(analysis_dir,'my_results');
database_dir      = fullfile(analysis_dir, 'my_databases');
txt_dir           = fullfile(database_dir,'txt_data');

%tools
addpath (genpath(fullfile(homedir,'/ANALYSIS/my_tools')));


%% LOOP TO EXTRACT DATA

if extract_subj_data == 1
    
    for  i=1:length(subj)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % load data
        
        subjX=char(subj(i,1)); % which subject?
        %disp (['******************************* PARTICIPANT: ' subjX ' ***************************************']);
        groupX = group(i); % which group did the subject belong?
        cd (behavior_dir) % go to behav folder to load subject data
        
        switch groupX % get the specifics according to the group (1 vs 3 days)
            case 1
                session   = {'01'};
                task_name = 'HAB1day';
                groupName = {'1'};%{'1-day'};
            case 2
                session = {'01'; '02'; '03'};
                task_name = 'HAB3day';
                groupName = {'3'};%{'3-day'};
        end
        
        for ii = 1:length(session)
            sessionX = char(session(ii,1));
            load (['sub-' num2str(subjX) '_task-' task_name '_session-' num2str(sessionX(end-1:end)) '.mat'])
            DATA.(['day' num2str(ii)]) = data;
            
        end
        
        cd (analysis_dir) % go back to analysis folder
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % database for devaluation manipulation check
        
        if strcmp(DATA.day1.target, 'sweet')
            
            ratings.pre.val(:,i)             = DATA.day1.initialRatings.savory;
            ratings.pre.deval(:,i)           = DATA.day1.initialRatings.sweet;
            ratings.pre.hunger(:,i)          = DATA.day1.initialRatings.hunger;
            
            % NEW, pre-ratings of the last session day, not 1st day as in habits_analysis_old.m // added by Mladena
            ratings.pre.val(:,i)            = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.savory;
            ratings.pre.deval(:,i)          = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.sweet;
            ratings.pre.hunger(:,i)         = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.hunger;
            
            ratings.post.val(:,i)            = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.salty;
            ratings.post.deval(:,i)          = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.sweet;
            ratings.post.hunger(:,i)         = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.hunger;
            
            % not pre-registered
            ratings.fractal.val(:,i)         = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.salty;
            ratings.fractal.deval(:,i)       = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.sweet;
            ratings.fractal.baseline(:,i)    = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.baseline;
            
            ratings.contingency.val(:,i)     = DATA.day1.contingencyTest.salty;
            ratings.contingency.deval(:,i)   = DATA.day1.contingencyTest.sweet;
            ratings.contingency.baseline(:,i)= DATA.day1.contingencyTest.baseline;
            
        elseif strcmp(DATA.day1.target, 'salty')
            
            % NEW, pre-ratings of the last session day, not 1st day as in habits_analysis_old.m // added by Mladena
            ratings.pre.val(:,i)            = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.sweet;
            ratings.pre.deval(:,i)          = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.savory;
            ratings.pre.hunger(:,i)         = DATA.(['day' num2str(length(fieldnames(DATA)))]).initialRatings.hunger;
            
            ratings.post.val(:,i)           = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.sweet;
            ratings.post.deval(:,i)         = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.salty;
            ratings.post.hunger(:,i)        = DATA.(['day' num2str(length(fieldnames(DATA)))]).finalRatings.hunger;
            
            % not pre-registered
            ratings.fractal.val(:,i)        = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.sweet;
            ratings.fractal.deval(:,i)      = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.salty;
            ratings.fractal.baseline(:,i)   = DATA.(['day' num2str(length(fieldnames(DATA)))]).fractalLiking.baseline;
            
            ratings.contingency.val(:,i)     = DATA.day1.contingencyTest.sweet;
            ratings.contingency.deval(:,i)   = DATA.day1.contingencyTest.salty;
            ratings.contingency.baseline(:,i)= DATA.day1.contingencyTest.baseline;
            
        end
        
        Rfood.liking (:,i)         = [ratings.pre.deval(:,i); ratings.pre.val(:,i);ratings.pre.hunger(:,i);ratings.post.deval(:,i);ratings.post.val(:,i); ratings.post.hunger(:,i)];
        Rfood.value (:,i)          = {'deval'               ;'val'                ;'hunger'               ;'deval'                ;'val'               ;'hunger' };
        Rfood.time (:,i)           = {'pre'                 ;'pre'                ;'pre'                  ;'post'                 ;'post'              ;'post'};
        Rfood.ID (:,i)             = repmat(str2double(subjX),length (Rfood.time(:,i)),1);
        Rfood.group (:,i)          = repmat(groupName,length (Rfood.time(:,i)),1);
        
        
        Rfractal.liking (:,i)      = [ratings.fractal.deval(:,i)    ; ratings.fractal.val(:,i)    ;ratings.fractal.baseline(:,i)];
        Rfractal.contingency (:,i) = [ratings.contingency.deval(:,i); ratings.contingency.val(:,i);ratings.contingency.baseline(:,i)];
        Rfractal.value (:,i)       = {'deval'                       ;'val'                        ;'baseline'   };
        Rfractal.ID  (:,i)         = repmat(str2double(subjX),length (Rfractal.value(:,i)),1);
        Rfractal.group (:,i)       = repmat(groupName,length (Rfractal.value(:,i)),1);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % database for instrumental responding analysis
        
        % pre-registred:
        
        % compute the DV of interest: difference of the mean pressing per
        % second during last run of training session and the extinction run
        
        % get the last run of the last day index
        idx.run      = find(DATA.(['day' num2str(length(fieldnames(DATA)))]).training.run == max(DATA.(['day' num2str(length(fieldnames(DATA)))]).training.run));
        
        list_name = {'valued'; 'devalued'; 'baseline'};
        
        for ii = 1:length(list_name)
            
            name = char (list_name (ii));
            
            % get the specifics of the condition during training
            idx.(name)    = strcmp(DATA.(['day' num2str(length(fieldnames(DATA)))]).training.value, name);
            idx.(name)    = idx.(name) (idx.run);
            % get the specifics of the condition during the last run
            frequence   = DATA.(['day' num2str(length(fieldnames(DATA)))]).training.pressFreq (idx.run);
            
            % get  mean responding by condition during last run
            responding.pre.(name) (:,i) = nanmean(frequence(idx.(name)));
            
            % get the specific of the condition during extinction
            idx.(name) = strcmp(DATA.(['day' num2str(length(fieldnames(DATA)))]).extinction.value, name);
            
            % get mean responding by condition during extinction
            responding.post.(name) (:,i) = nanmean(DATA.(['day' num2str(length(fieldnames(DATA)))]).extinction.pressFreq (idx.(name)));
            firstmin = DATA.(['day' num2str(length(fieldnames(DATA)))]).extinction.pressFreq (idx.(name));
            responding.post1min.(name) (:,i) = firstmin(1);

            % compute the differential index (post- pre) that will be our DV of
            % interest
            pressxsec.(name) (:,i) = responding.post.(name) (:,i) - responding.pre.(name) (:,i);
            pressxsec1min.(name) (:,i)  = responding.post1min.(name) (:,i) - responding.pre.(name) (:,i);
            
            
        end
        
        Rresponding.DV2(:,i)   = [responding.post.valued(:,i); responding.post.devalued(:,i); responding.post.baseline(:,i)];
        Rresponding.DV(:,i)    = [pressxsec.valued(:,i); pressxsec.devalued(:,i); pressxsec.baseline(:,i)];
        Rresponding.value(:,i) = {            'valued';               'devalued';              'baseline'};
        Rresponding.group(:,i) = repmat(groupName,length (Rresponding.value(:,i)),1);
        Rresponding.ID(:,i)    = repmat(str2double(subjX),length (Rresponding.value(:,i)),1);
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % training manipulation check
        
        
        if group(i) == 2
            list_day = {'day1'; 'day2'; 'day3'};
        else
            list_day = {'day1'};
        end
        
        
        for ii = 1:length(list_day)
            
            dayX = char (list_day (ii)); % get the day
            
            idx.valued   = strcmp(DATA.(dayX).training.value, 'valued');
            idx.devalued = strcmp(DATA.(dayX).training.value, 'devalued');
            
            if ~ all_subjects
                learning.(dayX).val(:,i)   = (DATA.(dayX).training.pressFreq (idx.valued));
                learning.(dayX).deval(:,i) = (DATA.(dayX).training.pressFreq (idx.devalued));
            end
            
            learning.(dayX).V =  (DATA.(dayX).training.pressFreq (idx.valued))';
            learning.(dayX).D =  (DATA.(dayX).training.pressFreq (idx.devalued))';
            
        end
        
        
        % determine exclusion criteria
        if group(i) == 2
            
            action_val   =  nanmean(nanmean([learning.day1.V,learning.day2.V, learning.day3.V]));
            action_deval =  nanmean(nanmean([learning.day1.D,learning.day2.D, learning.day3.D]));
            reference    =  nanmean([learning.day1.V, learning.day1.D,learning.day2.V, learning.day2.D, learning.day3.V, learning.day3.D],2);
            
        else
            action_val   = nanmean(learning.day1.V);
            action_deval = nanmean(learning.day1.D);
            reference    = nanmean([learning.day1.V, learning.day1.D],2);
            
        end
        
        variance_c   = nanstd(reference);
        
        action_variance(:,i) = variance_c;
        
        if abs (action_val - action_deval) >  3*variance_c
            
            disp ( (['exclude participant: ' subjX ' ']))
        end
        
    end
    
    %% Create Variable with Difference Index for each Group
    
    list_group = {'day1'; 'day3'};
    
    for ii = 1:length(list_group)
        
        groupvar = char(list_group(ii));
        idx.group.(groupvar) = find(group == ii);
        
        for iii = 1:length(list_name)
            name = char (list_name (iii));
            pressxsec.group.(groupvar).(name) = pressxsec.(name)(idx.group.(groupvar));
            presspost.group.(groupvar).(name) = responding.post.(name)(idx.group.(groupvar));
        
            pressxsec1min.group.(groupvar).(name) = pressxsec1min.(name)(idx.group.(groupvar));
            presspost1min.group.(groupvar).(name) = responding.post1min.(name)(idx.group.(groupvar));
        
            
        end
        
    end
   
    
    %% SAVE EXTRACTED DATA
    if save_results == 1
        
        cd (database_dir)
        cd ('matlab_data')
        save ([analysis_name '.mat'])
        cd(analysis_dir)
    end
    
elseif extract_subj_data == 0 % get extracted data
    
    cd (fullfile(database_dir, 'matlab_data'))
    load ([analysis_name '.mat'])
    cd(analysis_dir)
    
end

%% EXPORT DATA FOR R ANALYSIS
if save_results
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % food rating database: Rfood
    
    % random
    ID   = num2cell(Rfood.ID(:));
    % EV
    GROUP = Rfood.group(:);
    VALUE = Rfood.value(:);
    TIME  = Rfood.time(:);
    % DV
    liking = num2cell(Rfood.liking(:));
    % database
    database = [ID, GROUP, VALUE, TIME, liking];
    
    % write database in txt file
    cd (txt_dir)
    fid = fopen(['food_liking_' analysis_name '.txt'],'wt');
    
    % print heater
    fprintf (fid, '%s   %s      %s       %s     %s\n',...
        'ID','group','value', 'time', 'liking');
    
    % print data
    formatSpec = '%d   %s   %s   %s   %d\n';
    [nrows,ncols] = size(database);
    for row = 1:nrows
        fprintf(fid,formatSpec,database{row,:});
    end
    
    fclose(fid);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % fractal rating database;  Rfractal;
    
    % random
    ID   = num2cell(Rfractal.ID(:));
    
    % EV
    GROUP = Rfractal.group(:);
    VALUE = Rfractal.value(:);
    
    % DV
    liking      = num2cell(Rfractal.liking(:));
    contingency = num2cell(Rfractal.contingency(:));
    
    % database
    database = [ID, GROUP, VALUE, liking, contingency];
    
    % write database in txt file
    cd (txt_dir)
    fid = fopen(['fractal_ratings_' analysis_name '.txt'],'wt');
    
    % print heater
    fprintf (fid, '%s   %s      %s       %s     %s\n',...
        'ID','group','value', 'liking', 'contingency');
    
    % print data
    formatSpec = '%d   %s   %s   %d   %d\n';
    [nrows,ncols] = size(database);
    for row = 1:nrows
        fprintf(fid,formatSpec,database{row,:});
    end
    
    fclose(fid);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % intrumental responding database:  Rresponding
    
    % random
    ID   = num2cell(Rresponding.ID(:));
    % EV
    GROUP = Rresponding.group(:);
    VALUE = Rresponding.value(:);
    
    % DV
    presses_change = num2cell(Rresponding.DV(:));
    presses_post   = num2cell(Rresponding.DV2(:));
    
    % database
    database = [ID, GROUP, VALUE, presses_change, presses_post];
    
    % write database in txt file
    cd (txt_dir)
    fid = fopen(['presses_' analysis_name '.txt'],'wt');
    
    % print heater
    fprintf (fid, '%s   %s      %s       %s       %s\n',...
        'ID','group','value', 'presses_change', 'presses_post');
    
    % print data
    formatSpec = '%d   %s   %s   %d   %d\n';
    [nrows,ncols] = size(database);
    for row = 1:nrows
        fprintf(fid,formatSpec,database{row,:});
    end
    
    fclose(fid);
    
end

%% PLOT DATA BY GROUP AND CONDITION
if graph_on
    
    
    if all_subjects == 1
        
        create_diffIndex_plot('Difference Index [post-pre]', pressxsec.group.day1,...
            pressxsec.group.day3);
        
    else
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % TIME INTERACTIONS
        % plot food liking
        create_prepost_plot ('Food liking', ratings.pre, ratings.post);
        % plot fractal responding
        create_prepost_plot ('Responding ', responding.pre, responding.post);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MEANS
        % liking ratings
        create_plot_means ('Fractal liking', ratings.fractal);
        
        % contincencies ratings
        create_plot_means ('Fractal contingencies', ratings.contingency);
 
        % impact of devaluation on reponding
        post_index.day1   = presspost.group.day1.valued-presspost.group.day1.devalued;
        post_index.day3   = presspost.group.day3.valued-presspost.group.day3.devalued;
        
        change_index.day1 = pressxsec.group.day1.valued-pressxsec.group.day1.devalued;
        change_index.day3 = pressxsec.group.day3.valued-pressxsec.group.day3.devalued;
              
        create_plot_means_simple ('impact of devaluation on change index',  change_index);
        create_plot_means_simple ('impact of devaluation on post pressing',  post_index);

    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LEARNING TRAJECTORIES

if ~ all_subjects
    ndays = length(fieldnames(learning));
    figure;
    
    for i = 1:ndays
        
        dayX = ['day' num2str(i)];
        
        subplot(1,3,i)
        title( ['Day' num2str(i)] )
        hold
        plot(nanmean(learning.(dayX).deval,2),'-o', 'color', [0.2 0.2 0.2], 'MarkerFaceColor',[0 0 0] )
        plot(nanmean(learning.(dayX).val,2),'-o', 'color',  [0.5 0.8 0.1],'MarkerFaceColor',[0.5 0.8 0.1])
        %ylim([2 5])
        if i == 1
            ylabel('Responding')
        end
        
        xlabel('Training Trials')
    end
    
    set(gcf, 'Position', [50 100 1200 400])
    set(gcf, 'Color', 'w')
    box off
    
    LEG = legend('Devalued','Valued');
    set(LEG,'FontSize',12); %
    set(LEG,'Box', 'off');
    set(LEG, 'Position', [0.850 0.400 0.150 0.100])
end


