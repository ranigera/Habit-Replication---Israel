function graph = create_plot_means (pattern, data1)



means = structfun(@nanmean,  data1);
sems = structfun(@(x) nanstd(x)/sqrt(length(x)), data1);


color.means.val = [0.5 0.8 0.1];
color.edge.val = [0.5 0.8 0.1];

color.means.deval = [0.2 0.2 0.2];
color.edge.deval = [0.2 0.2 0.2];

color.means.baseline = [0.8 0.1 0.1];
color.edge.baseline  = [.9 .9 .9];


graph = figure;

y = means ((1:length(means)));
bars = sems (1:length(sems));

hold on

names = {'val', 'deval', 'baseline'};

for i = 1:length(names)
    
    name = char(names(i));
    
    bar(i,y(i), 0.5, 'faceColor', color.means.(name), 'EdgeColor', color.edge.(name), 'LineWidth', 1);
end

errorbar(1:length(sems),y,bars,'.k', 'LineWidth', 1);
set(gca, 'XTickLabel', '')
ylabel(pattern,'FontSize',24)
ypos = min(ylim)-0.005;



labelx = {names{1},names{2},names{3}};
text([0.85  1.85  2.9],repmat(ypos,length(means),1), ...
    labelx,'verticalalignment','cap','FontSize',24)


set(gcf, 'Position', [50 100 300 600])
set(gcf, 'Color', 'w')
box off
