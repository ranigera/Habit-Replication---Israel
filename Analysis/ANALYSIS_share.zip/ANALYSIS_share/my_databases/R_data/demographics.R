#############################
# Demographics              #
# Analyses                  #
#############################

#####################################
# Created in August 2017 by Mladena #
#####################################

# set working directory
demographics_path <- '/Users/Mladena/Box Sync/HABITS/DATA/questionnaires'
setwd(demographics_path)

#
#install.packages("gdata")        # install package
library(gdata)                   # load gdata package 
#help(read.xls)                   # documentation 

# import csv dataset (excel)
library(readr)
Demographics <- read_csv("~/Box Sync/HABITS/ANALYSIS/my_databases/R_data/Demographics.csv", 
col_types = cols(Allergies = col_factor(levels = c("none", 
"related", "notrelated")), Excluded = col_factor(levels = c("yes", "no")), Gender = col_factor(levels = c("male", 
"female","nonbinary")), Group = col_factor(levels = c("1", "3")), Hand = col_factor(levels = c("right", "left")), LastMeal = col_double()))      

####### descriptive statistics ########

# overall mean, range, frequency
summary(Demographics)

# overall sd
library(psych)
describe(Demographics)

# frequency tables by Group

attach(Demographics)
mytable <- table(Gender,Group) # A will be rows, B will be columns 
mytable # print table 

mytable2 <- table(Allergies,Group) # A will be rows, B will be columns 
mytable2 # print table 

# demographics of continous variables by Group
library(psych)
describeBy(Demographics, group=Group)

# Boxplot